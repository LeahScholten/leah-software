Gemaakt door Michael Scholten van michaeljoy.nl.
Geef de te lezen map(pen) als argument bij het starten van het programma.
Het zal zoeken naar alle mappen met de naam target en een Cargo.toml bestand in de meegegeven map(pen).
Als het zo'n target map gevonden heeft, zal het die map verwijderen.
