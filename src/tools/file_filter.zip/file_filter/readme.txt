Gemaakt door Michael Scholten van michaeljoy.nl.
Geef de te lezen map(pen) als argument bij het starten van het programma.
Eerst worden de meegegeven mappen gefilterd.
Als alle meegegeven mappen gefilterd zijn, wordt gevraagd om een volgende in te voeren tot je de applicatie sluit.

Iedere meegegeven map wordt individueel gefilterd.
Alle bestanden in de meegegeven map wordt met alle andere bestanden gefilterd, dit werkt recursief (droste effect).
